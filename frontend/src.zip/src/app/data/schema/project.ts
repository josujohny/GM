export class Project {
  link: string;
  title: string;
  thumbnail: string;
}
