export class Grocery {
    name: string;
    imageUrl: string;
}
