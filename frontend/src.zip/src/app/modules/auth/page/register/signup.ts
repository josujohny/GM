export class Signup {
    fname: string;
    lname: string;
    username: string;
    email: string;
    address: string;
    phone: number;
}
