export class List {
    id: Number;
    category: string;
  }