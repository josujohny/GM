
import { List } from './list';


    export const LISTS: List[] = [
    { id: 1, category: 'bakery' },
    { id: 2, category: 'fruits' },
    { id: 3, category: 'vegitable' },
    { id: 4, category: 'bakery' },
    { id: 5, category: 'cleaner' }
  ];